using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private LayerMask wallLayer;

    private Rigidbody2D rb;
    private Vector2 movement;
    private float collisionOffset = 0.05f;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Get input
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        // Normalize diagonal movement
        if (movement.magnitude > 1)
        {
            movement.Normalize();
        }
    }

    void FixedUpdate()
    {
        if (movement != Vector2.zero)
        {
            MovePlayer();
        }
    }

    void MovePlayer()
    {
        // Calculate target position
        Vector2 targetPosition = rb.position + movement * moveSpeed * Time.fixedDeltaTime;

        // Check for collisions
        if (!CheckCollision(targetPosition))
        {
            rb.MovePosition(targetPosition);
        }
        else
        {
            // Try moving only in X direction
            Vector2 tryXPosition = rb.position + new Vector2(movement.x, 0) * moveSpeed * Time.fixedDeltaTime;
            if (!CheckCollision(tryXPosition))
            {
                rb.MovePosition(tryXPosition);
            }

            // Try moving only in Y direction
            Vector2 tryYPosition = rb.position + new Vector2(0, movement.y) * moveSpeed * Time.fixedDeltaTime;
            if (!CheckCollision(tryYPosition))
            {
                rb.MovePosition(tryYPosition);
            }
        }
    }

    bool CheckCollision(Vector2 position)
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(position, collisionOffset, wallLayer);
        return colliders.Length > 0;
    }
}