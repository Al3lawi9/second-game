using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    [SerializeField] private Text timerText;

    void Update()
    {
        if (GameManager.Instance != null && timerText != null)
        {
            float currentTime = GameManager.Instance.GetCurrentTime();
            timerText.text = "Time: " + GameManager.Instance.FormatTime(currentTime);
        }
    }
}