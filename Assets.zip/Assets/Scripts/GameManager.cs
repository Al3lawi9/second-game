using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [SerializeField] private float levelTimer = 0f;
    private bool isTimerRunning = false;
    private string currentLevel;

    // Dictionary to store best times for each level
    private Dictionary<string, float> levelBestTimes = new Dictionary<string, float>();

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Update()
    {
        if (isTimerRunning)
        {
            levelTimer += Time.deltaTime;
        }
    }

    public void StartLevel(string levelName)
    {
        currentLevel = levelName;
        ResetTimer();
        isTimerRunning = true;
        SceneManager.LoadScene(levelName);
    }

    public void CompleteLevel()
    {
        isTimerRunning = false;

        // Check if this is a new best time
        if (!levelBestTimes.ContainsKey(currentLevel) || levelTimer < levelBestTimes[currentLevel])
        {
            levelBestTimes[currentLevel] = levelTimer;
            Debug.Log($"New best time for {currentLevel}: {FormatTime(levelTimer)}");
        }

        // Return to main menu
        SceneManager.LoadScene("MainMenu");
    }

    public void ResetTimer()
    {
        levelTimer = 0f;
    }

    public float GetCurrentTime()
    {
        return levelTimer;
    }

    public string FormatTime(float time)
    {
        int minutes = Mathf.FloorToInt(time / 60);
        int seconds = Mathf.FloorToInt(time % 60);
        int milliseconds = Mathf.FloorToInt((time * 1000) % 1000);

        return string.Format("{0:00}:{1:00}:{2:000}", minutes, seconds, milliseconds);
    }

    public float GetBestTime(string levelName)
    {
        if (levelBestTimes.ContainsKey(levelName))
        {
            return levelBestTimes[levelName];
        }
        return 0f;
    }
}