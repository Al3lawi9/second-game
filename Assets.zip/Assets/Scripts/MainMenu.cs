using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class MainMenu : MonoBehaviour
{
    [SerializeField] private Button level1Button;
    [SerializeField] private Button level2Button;
    [SerializeField] private Button level3Button;
    [SerializeField] private Button quitButton;

    [SerializeField] private Text level1BestTime;
    [SerializeField] private Text level2BestTime;
    [SerializeField] private Text level3BestTime;

    [SerializeField] private string level1Name = "Level1";
    [SerializeField] private string level2Name = "Level2";
    [SerializeField] private string level3Name = "Level3";

    void Start()
    {
        // Add listeners to buttons
        if (level1Button != null)
            level1Button.onClick.AddListener(() => StartLevel(level1Name));

        if (level2Button != null)
            level2Button.onClick.AddListener(() => StartLevel(level2Name));

        if (level3Button != null)
            level3Button.onClick.AddListener(() => StartLevel(level3Name));

        if (quitButton != null)
            quitButton.onClick.AddListener(QuitGame);
    }

    void Update()
    {
        // Update best times display
        UpdateBestTimes();
    }

    void StartLevel(string levelName)
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.StartLevel(levelName);
        }
        else
        {
            SceneManager.LoadScene(levelName);
        }
    }

    void UpdateBestTimes()
    {
        if (GameManager.Instance != null)
        {
            if (level1BestTime != null)
                UpdateBestTimeText(level1BestTime, level1Name);

            if (level2BestTime != null)
                UpdateBestTimeText(level2BestTime, level2Name);

            if (level3BestTime != null)
                UpdateBestTimeText(level3BestTime, level3Name);
        }
    }

    void UpdateBestTimeText(Text text, string levelName)
    {
        float bestTime = GameManager.Instance.GetBestTime(levelName);
        if (bestTime > 0)
        {
            text.text = "Best: " + GameManager.Instance.FormatTime(bestTime);
        }
        else
        {
            text.text = "Best: --:--:---";
        }
    }

    void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
    }
}