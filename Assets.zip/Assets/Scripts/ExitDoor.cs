using UnityEngine;

public class ExitDoor : MonoBehaviour
{
    [SerializeField] private string nextLevelName; // Optional: for sequential level loading

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // Complete the level
            if (GameManager.Instance != null)
            {
                GameManager.Instance.CompleteLevel();
            }
            else
            {
                // Fallback if no GameManager
                UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
            }
        }
    }
}